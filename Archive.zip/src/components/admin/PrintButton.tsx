"use client";
import { Printer } from "lucide-react";

export function PrintButton() {
  return (
    <button onClick={() => window.print()} className="btn-outline-dark print:hidden">
      <Printer className="h-4 w-4" /> Print Schedule
    </button>
  );
}
